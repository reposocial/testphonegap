document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady ()
{
	
	concole.log ('Device Ready....');
}

